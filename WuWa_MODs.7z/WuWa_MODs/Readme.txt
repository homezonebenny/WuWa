URL:
https://www.nexusmods.com/wutheringwaves/mods/17


1. Copy Engine.ini and Scalability.ini into:
..Wuthering Waves\Wuthering Waves Game\Client\Saved\Config\WindowsNoEditor


2. Copy ~mods folder into:
D:\Games\Wuthering Waves\Wuthering Waves Game\Client\Content\Paks


3. Delete ONE file out of the ~mods folder:
 - WuWa-TweaksF_99_P (Fullscreen Mode)
 - WuWa-Tweaks_99_P (Windowed Mode)
If you play Windowed (Fullscreen) then delete "WuWa-TweaksF_99_P" else "WuWa-Tweaks_99_P"


4. Create a new shortcut:
D:\Games\Wuthering Waves\Wuthering Waves Game\Client\Binaries\Win64\Client-Win64-Shipping.exe
Add a:
-fileopenlog
to the "Target" path of the shortcut, like this example:
"D:\Games\Wuthering Waves\Wuthering Waves Game\Client\Binaries\Win64\Client-Win64-Shipping.exe" -fileopenlog